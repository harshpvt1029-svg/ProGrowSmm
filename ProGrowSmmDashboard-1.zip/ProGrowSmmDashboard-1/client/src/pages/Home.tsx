import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Zap, Shield, TrendingUp, Users, Clock, Award, Star } from "lucide-react";
import { useEffect, useState } from "react";

function AnimatedCounter({ end, duration = 2000, suffix = "" }: { end: number; duration?: number; suffix?: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, [end, duration]);

  return <span>{count.toLocaleString()}{suffix}</span>;
}

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/95">
      <header className="sticky top-0 z-50 glass-card border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-md bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center neon-glow-sm">
                <Zap className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold gradient-text" data-testid="text-logo">ProGrowSMM</span>
            </div>
            
            <nav className="hidden md:flex items-center gap-6">
              <a href="#features" className="text-sm text-foreground hover:text-primary transition-colors" data-testid="link-features">Features</a>
              <a href="#stats" className="text-sm text-foreground hover:text-primary transition-colors" data-testid="link-stats">Stats</a>
              <a href="#testimonials" className="text-sm text-foreground hover:text-primary transition-colors" data-testid="link-testimonials">Testimonials</a>
            </nav>

            <div className="flex items-center gap-3">
              <Link href="/login">
                <Button variant="ghost" size="sm" data-testid="button-login">
                  Log In
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm" className="neon-glow-sm" data-testid="button-get-started">
                  Get Started
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden py-20 sm:py-32">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-transparent opacity-50" />
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(0, 191, 255, 0.15) 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto">
            <Badge className="mb-6 glass-card neon-glow-sm" data-testid="badge-fastest">
              <Zap className="w-3 h-3 mr-1" />
              Fastest SMM Panel
            </Badge>
            
            <h1 className="text-4xl sm:text-6xl font-extrabold mb-6 leading-tight" data-testid="text-hero-title">
              <span className="gradient-text neon-text">Supercharge</span> Your Social Media Growth
            </h1>
            
            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-hero-subtitle">
              Get instant followers, likes, views, and engagement from the most trusted SMM panel. 
              Lightning-fast delivery, premium quality, 24/7 support.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <Link href="/register">
                <Button size="lg" className="neon-glow text-lg px-8 group" data-testid="button-hero-start">
                  Start Growing Now
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="glass-card text-lg px-8" data-testid="button-hero-services">
                View Services
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
              {[
                { icon: Users, label: "50K+ Users", value: "50000" },
                { icon: Clock, label: "Instant Delivery", value: "24/7" },
                { icon: Award, label: "99.9% Uptime", value: "99.9" }
              ].map((stat, idx) => (
                <Card key={idx} className="glass-card p-4 border-border/50 hover-elevate" data-testid={`card-hero-stat-${idx}`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                      <stat.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="text-left">
                      <div className="text-lg font-bold text-foreground" data-testid={`text-stat-value-${idx}`}>{stat.value}</div>
                      <div className="text-xs text-muted-foreground" data-testid={`text-stat-label-${idx}`}>{stat.label}</div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-gradient-to-b from-transparent to-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" data-testid="text-features-title">
              Why Choose <span className="gradient-text">ProGrowSMM</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-features-subtitle">
              Experience the difference with our premium features designed for maximum growth
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Zap,
                title: "Lightning Fast",
                description: "Orders start processing instantly. See results in minutes, not hours.",
                color: "from-yellow-500 to-orange-500"
              },
              {
                icon: Shield,
                title: "100% Safe & Secure",
                description: "Enterprise-grade security. Your data and accounts are always protected.",
                color: "from-green-500 to-emerald-500"
              },
              {
                icon: TrendingUp,
                title: "Real Growth",
                description: "Authentic engagement from real users. No bots, no fake accounts.",
                color: "from-blue-500 to-cyan-500"
              },
              {
                icon: Award,
                title: "Premium Quality",
                description: "Top-tier services with guaranteed delivery and 99.9% success rate.",
                color: "from-purple-500 to-pink-500"
              }
            ].map((feature, idx) => (
              <Card 
                key={idx} 
                className="glass-card p-6 border-border/50 hover-elevate group cursor-pointer"
                data-testid={`card-feature-${idx}`}
              >
                <div className={`w-14 h-14 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 neon-glow-sm group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-foreground" data-testid={`text-feature-title-${idx}`}>
                  {feature.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed" data-testid={`text-feature-desc-${idx}`}>
                  {feature.description}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="stats" className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-blue-600/20 to-cyan-600/20 animate-gradient" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-5xl font-bold mb-4 gradient-text neon-text" data-testid="text-stats-title">
              Our Impact in Numbers
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-stats-subtitle">
              Join thousands of satisfied customers growing their online presence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: "Orders Completed", value: 2847563, suffix: "+" },
              { label: "Active Users", value: 54892, suffix: "+" },
              { label: "Services Available", value: 156, suffix: "" },
              { label: "Success Rate", value: 99.9, suffix: "%" }
            ].map((stat, idx) => (
              <Card key={idx} className="glass-card p-8 border-border/50 text-center hover-elevate" data-testid={`card-stat-${idx}`}>
                <div className="text-4xl sm:text-5xl font-extrabold mb-2 gradient-text" data-testid={`text-stat-number-${idx}`}>
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-sm text-muted-foreground font-medium" data-testid={`text-stat-label-${idx}`}>
                  {stat.label}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="testimonials" className="py-20 bg-gradient-to-b from-transparent to-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4" data-testid="text-testimonials-title">
              What Our <span className="gradient-text">Customers Say</span>
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-testimonials-subtitle">
              Real feedback from real users who transformed their social presence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Sarah Johnson",
                role: "Content Creator",
                avatar: "SJ",
                rating: 5,
                text: "ProGrowSMM helped me grow from 500 to 50K followers in just 3 months. The quality is unmatched!"
              },
              {
                name: "Mike Chen",
                role: "Digital Marketer",
                avatar: "MC",
                rating: 5,
                text: "Best SMM panel I've used. Fast delivery, real engagement, and amazing customer support. Highly recommend!"
              },
              {
                name: "Emily Rodriguez",
                role: "Influencer",
                avatar: "ER",
                rating: 5,
                text: "The results speak for themselves. My engagement rate doubled and my brand deals tripled. Thank you!"
              }
            ].map((testimonial, idx) => (
              <Card key={idx} className="glass-card p-6 border-border/50 hover-elevate" data-testid={`card-testimonial-${idx}`}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center text-white font-semibold neon-glow-sm" data-testid={`avatar-${idx}`}>
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-foreground" data-testid={`text-testimonial-name-${idx}`}>{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground" data-testid={`text-testimonial-role-${idx}`}>{testimonial.role}</div>
                  </div>
                </div>
                <div className="flex gap-1 mb-3">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" data-testid={`star-${idx}-${i}`} />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed" data-testid={`text-testimonial-text-${idx}`}>
                  "{testimonial.text}"
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <footer className="glass-card border-t border-border/50 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-md bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center neon-glow-sm">
                  <Zap className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="font-bold gradient-text" data-testid="text-footer-logo">ProGrowSMM</span>
              </div>
              <p className="text-sm text-muted-foreground" data-testid="text-footer-tagline">
                The fastest and most reliable SMM panel for all your social media growth needs.
              </p>
            </div>

            {[
              {
                title: "Quick Links",
                links: ["Home", "Services", "Pricing", "About Us"]
              },
              {
                title: "Services",
                links: ["Instagram", "Facebook", "Twitter", "YouTube"]
              },
              {
                title: "Support",
                links: ["Help Center", "Contact Us", "Terms of Service", "Privacy Policy"]
              }
            ].map((section, idx) => (
              <div key={idx}>
                <h3 className="font-semibold mb-4 text-foreground" data-testid={`text-footer-section-${idx}`}>{section.title}</h3>
                <ul className="space-y-2">
                  {section.links.map((link, linkIdx) => (
                    <li key={linkIdx}>
                      <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors" data-testid={`link-footer-${idx}-${linkIdx}`}>
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="pt-8 border-t border-border/50 text-center text-sm text-muted-foreground" data-testid="text-copyright">
            © 2024 ProGrowSMM. All rights reserved. Built with premium quality.
          </div>
        </div>
      </footer>
    </div>
  );
}
