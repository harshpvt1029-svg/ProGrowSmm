import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  Wallet, 
  Settings, 
  LogOut,
  TrendingUp,
  Clock,
  CheckCircle2,
  DollarSign,
  Zap,
  Plus,
  Loader2,
  Instagram,
  Send,
  Youtube,
  Facebook,
  Grid3x3
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { getToken, logout, getStoredUser } from "@/lib/auth";
import { AnimatePresence, motion } from "framer-motion";
import type { Category, Service } from "@shared/schema";

const categoryIcons: Record<string, any> = {
  instagram: Instagram,
  telegram: Send,
  youtube: Youtube,
  facebook: Facebook,
  others: Grid3x3,
};

export default function Dashboard() {
  const [location, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("");
  
  useEffect(() => {
    const token = getToken();
    if (!token) {
      setLocation("/login");
    }
  }, [setLocation]);

  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ["/api/user"],
    enabled: !!getToken(),
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: services, isLoading: servicesLoading } = useQuery<Service[]>({
    queryKey: ["/api/categories", selectedCategory, "services"],
    enabled: !!selectedCategory,
  });

  useEffect(() => {
    if (categories && categories.length > 0 && !selectedCategory) {
      setSelectedCategory(categories[0].slug);
    }
  }, [categories, selectedCategory]);

  const storedUser = getStoredUser();
  const user = (userData || storedUser || {
    username: "User",
    email: "user@example.com",
    avatar: null,
    balance: 0,
    ordersCompleted: 0,
    activeServices: 0,
  }) as {
    username: string;
    email: string;
    avatar: string | null;
    balance: number;
    ordersCompleted: number;
    activeServices: number;
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (userLoading || categoriesLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
    { icon: ShoppingCart, label: "New Order", path: "/dashboard/new-order" },
    { icon: Package, label: "Orders", path: "/dashboard/orders" },
    { icon: Wallet, label: "Wallet", path: "/dashboard/wallet" },
    { icon: Settings, label: "Settings", path: "/dashboard/settings" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex">
      <aside className="w-64 glass-card border-r border-border/50 flex flex-col">
        <div className="p-6 border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-md bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center neon-glow-sm">
              <Zap className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold gradient-text" data-testid="text-logo">ProGrowSMM</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                className={`w-full justify-start gap-3 ${
                  location === item.path 
                    ? "bg-primary/10 text-primary hover:bg-primary/20" 
                    : "hover-elevate"
                }`}
                data-testid={`button-nav-${item.label.toLowerCase().replace(" ", "-")}`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Button>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-border/50">
          <div className="flex items-center gap-3 mb-4">
            <Avatar className="border-2 border-primary/50 neon-glow-sm">
              <AvatarFallback className="bg-gradient-to-br from-primary to-blue-600 text-primary-foreground font-semibold">
                {getInitials(user.username || "User")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-foreground truncate" data-testid="text-username">
                {user.username}
              </div>
              <div className="text-xs text-muted-foreground truncate" data-testid="text-email">
                {user.email}
              </div>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="w-full glass-card border-border/50" 
            onClick={logout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Log Out
          </Button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <div className="p-6 sm:p-8 max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2" data-testid="text-welcome">
              Welcome back, <span className="gradient-text">{user.username}</span>!
            </h1>
            <p className="text-muted-foreground" data-testid="text-dashboard-subtitle">
              Choose a category and select the service you need
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[
              {
                icon: CheckCircle2,
                label: "Orders Completed",
                value: user.ordersCompleted || 0,
                color: "from-green-500 to-emerald-500",
                testId: "completed"
              },
              {
                icon: DollarSign,
                label: "Balance",
                value: `$${(user.balance || 0).toFixed(2)}`,
                color: "from-blue-500 to-cyan-500",
                testId: "balance"
              },
              {
                icon: TrendingUp,
                label: "Active Services",
                value: user.activeServices || 0,
                color: "from-purple-500 to-pink-500",
                testId: "active"
              },
              {
                icon: Clock,
                label: "Pending Orders",
                value: 0,
                color: "from-yellow-500 to-orange-500",
                testId: "pending"
              }
            ].map((stat) => (
              <Card key={stat.label} className="glass-card p-6 border-border/50 hover-elevate" data-testid={`card-stat-${stat.testId}`}>
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center neon-glow-sm`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-foreground mb-1" data-testid={`text-stat-value-${stat.testId}`}>
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground" data-testid={`text-stat-label-${stat.testId}`}>
                  {stat.label}
                </div>
              </Card>
            ))}
          </div>

          <Card className="glass-card p-6 border-border/50" data-testid="card-services">
            <h2 className="text-2xl font-semibold mb-6 gradient-text" data-testid="text-services-title">
              Browse Services
            </h2>

            <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
              <TabsList className="glass-card border-border/50 mb-6 flex-wrap h-auto gap-2 p-2" data-testid="tabs-categories">
                {categories?.map((category) => {
                  const Icon = categoryIcons[category.slug] || Grid3x3;
                  return (
                    <TabsTrigger
                      key={category.slug}
                      value={category.slug}
                      className="gap-2 data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                      data-testid={`tab-${category.slug}`}
                    >
                      <Icon className="w-4 h-4" />
                      {category.name}
                    </TabsTrigger>
                  );
                })}
              </TabsList>

              {categories?.map((category) => (
                <TabsContent key={category.slug} value={category.slug} className="mt-0">
                  <div className="mb-4">
                    <p className="text-muted-foreground text-sm" data-testid={`text-category-description-${category.slug}`}>
                      {category.description}
                    </p>
                  </div>

                  {servicesLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    </div>
                  ) : (
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={selectedCategory}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.3 }}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
                      >
                        {services && services.length > 0 ? (
                          services.map((service) => (
                            <Card
                              key={service.id}
                              className="glass-card p-5 border-border/50 hover-elevate transition-all"
                              data-testid={`service-card-${service.id}`}
                            >
                              <div className="mb-3">
                                <h3 className="font-semibold text-foreground mb-2" data-testid={`service-name-${service.id}`}>
                                  {service.name}
                                </h3>
                                <p className="text-xs text-muted-foreground line-clamp-2" data-testid={`service-description-${service.id}`}>
                                  {service.description}
                                </p>
                              </div>

                              <div className="flex items-center gap-2 mb-3">
                                <Badge variant="secondary" className="text-xs">
                                  Min: {service.minOrder}
                                </Badge>
                                <Badge variant="secondary" className="text-xs">
                                  Max: {service.maxOrder.toLocaleString()}
                                </Badge>
                              </div>

                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="text-xs text-muted-foreground">Price</div>
                                  <div className="text-lg font-bold text-primary" data-testid={`service-price-${service.id}`}>
                                    ${service.pricePerUnit}/1k
                                  </div>
                                </div>
                                <Button size="sm" className="neon-glow-sm" data-testid={`button-order-${service.id}`}>
                                  <Plus className="w-3 h-3 mr-1" />
                                  Order
                                </Button>
                              </div>
                            </Card>
                          ))
                        ) : (
                          <div className="col-span-full text-center py-12">
                            <p className="text-muted-foreground">No services available in this category</p>
                          </div>
                        )}
                      </motion.div>
                    </AnimatePresence>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </Card>
        </div>
      </main>
    </div>
  );
}
