# ProGrowSMM - Social Media Marketing Panel

## Overview

ProGrowSMM is a premium SMM (Social Media Marketing) panel application that provides social media marketing services. The platform features a dark, futuristic design with neon blue accents and glass-morphism effects, inspired by high-end SMM panels. Users can register, login (including Google OAuth), access a dashboard, and manage their social media marketing services.

The application is built as a full-stack TypeScript application with a React frontend and Express backend, using PostgreSQL with Drizzle ORM for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast HMR (Hot Module Replacement)
- Wouter for lightweight client-side routing instead of React Router

**UI Component System**
- shadcn/ui component library (New York style variant) for consistent, accessible UI components
- Radix UI primitives for headless, accessible component foundations
- Tailwind CSS for utility-first styling with custom design tokens
- Class Variance Authority (CVA) for component variant management

**Design System**
- Dark mode-first approach with custom CSS variables for theming
- Poppins font family from Google Fonts for modern typography
- Glass-morphism effects and neon blue glow accents throughout
- Custom color palette with HSL-based variables for background, foreground, primary, secondary, muted, accent, and destructive states
- Responsive design with mobile-first breakpoints

**State Management**
- TanStack Query (React Query) for server state management, caching, and data fetching
- Local storage for authentication token and user data persistence
- React Hook Form with Zod validation for form state and validation

**Authentication Flow**
- JWT-based authentication stored in localStorage
- Token included in API requests via Authorization header
- Protected routes redirect to login when unauthenticated
- User data cached locally and synchronized with server

### Backend Architecture

**Server Framework**
- Express.js for HTTP server and routing
- TypeScript for type safety across the backend
- Custom middleware for authentication, logging, and request processing

**Authentication & Authorization**
- JWT (JSON Web Tokens) for stateless authentication with 7-day expiration
- bcryptjs for password hashing with salt rounds
- Passport.js with Google OAuth 2.0 strategy for social login
- Session secret required via environment variable
- Token verification middleware for protected routes

**API Design**
- RESTful API endpoints under `/api` prefix
- JSON request/response format
- Standardized error handling with appropriate HTTP status codes
- Request logging middleware that captures method, path, status, duration, and response body

**Database Layer**
- Drizzle ORM for type-safe database queries and schema management
- Storage abstraction layer (IStorage interface) for potential future database swapping
- DatabaseStorage implementation using Drizzle queries
- Schema-first approach with TypeScript type inference

**Development Tools**
- Vite development server integrated with Express in middleware mode
- Custom logging utility for formatted server-side logs
- Hot module replacement for frontend during development
- TSX for running TypeScript directly in development

### Data Storage

**Database**
- PostgreSQL via Neon serverless driver with WebSocket support
- Connection pooling for efficient database connections
- Drizzle Kit for schema migrations and database push operations

**Schema Design**
- `users` table with the following structure:
  - `id`: UUID primary key (auto-generated)
  - `email`: Unique, required text field
  - `username`: Required text field
  - `password`: Optional text field (null for OAuth users)
  - `googleId`: Optional unique field for Google OAuth users
  - `avatar`: Optional text field for profile image URL
  - `balance`: Integer with default 0 (for user wallet/credits)
  - `ordersCompleted`: Integer with default 0 (analytics)
  - `activeServices`: Integer with default 0 (analytics)
  - `createdAt`: Timestamp with default now()

**Data Validation**
- Zod schemas for runtime validation of user input
- Drizzle-Zod integration for automatic schema generation from database schema
- Separate schemas for registration, login, and user insertion

### External Dependencies

**Third-Party Services**
- Google OAuth 2.0 for social authentication (requires GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET)
- Neon Database for PostgreSQL hosting
- Google Fonts CDN for Poppins font family

**Key Libraries**
- `@neondatabase/serverless`: PostgreSQL client with WebSocket support
- `drizzle-orm`: Type-safe ORM with PostgreSQL dialect
- `jsonwebtoken`: JWT creation and verification
- `bcryptjs`: Password hashing
- `passport` & `passport-google-oauth20`: OAuth authentication
- `react-hook-form`: Form state management
- `zod`: Schema validation
- `@tanstack/react-query`: Server state management
- `wouter`: Lightweight routing
- `tailwindcss`: Utility-first CSS framework

**Environment Variables Required**
- `DATABASE_URL`: PostgreSQL connection string (required)
- `SESSION_SECRET`: Secret key for JWT signing (required)
- `GOOGLE_CLIENT_ID`: Google OAuth client ID (optional, for OAuth)
- `GOOGLE_CLIENT_SECRET`: Google OAuth client secret (optional, for OAuth)
- `REPL_ID`: Replit deployment identifier (optional, for production URL)
- `NODE_ENV`: Environment mode (development/production)

**Build & Deployment**
- Development: `npm run dev` - Runs TSX server with Vite dev middleware
- Build: `npm run build` - Builds frontend with Vite, bundles backend with esbuild
- Production: `npm start` - Runs compiled server from dist directory
- Database: `npm run db:push` - Pushes schema changes to database