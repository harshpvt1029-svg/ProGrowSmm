import { db } from "./db";
import { categories, services } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  const categoriesData = [
    {
      name: "Instagram",
      slug: "instagram",
      icon: "instagram",
      description: "Grow your Instagram presence with authentic engagement",
      order: 1,
    },
    {
      name: "Telegram",
      slug: "telegram",
      icon: "send",
      description: "Boost your Telegram channels and groups with real members",
      order: 2,
    },
    {
      name: "YouTube",
      slug: "youtube",
      icon: "youtube",
      description: "Boost your YouTube channel with real views and subscribers",
      order: 3,
    },
    {
      name: "Facebook",
      slug: "facebook",
      icon: "facebook",
      description: "Enhance your Facebook reach with quality engagement",
      order: 4,
    },
    {
      name: "Others",
      slug: "others",
      icon: "grid",
      description: "More social media platforms and services",
      order: 5,
    },
  ];

  console.log("Creating categories...");
  const createdCategories = await db
    .insert(categories)
    .values(categoriesData)
    .onConflictDoNothing()
    .returning();
  
  console.log(`Created ${createdCategories.length} categories`);

  const instagramId = createdCategories.find(c => c.slug === "instagram")?.id || 1;
  const telegramId = createdCategories.find(c => c.slug === "telegram")?.id || 2;
  const youtubeId = createdCategories.find(c => c.slug === "youtube")?.id || 3;
  const facebookId = createdCategories.find(c => c.slug === "facebook")?.id || 4;
  const othersId = createdCategories.find(c => c.slug === "others")?.id || 5;

  const servicesData = [
    {
      categoryId: instagramId,
      name: "Instagram Followers - High Quality",
      description: "Get premium Instagram followers from real accounts. Fast delivery, no password required.",
      pricePerUnit: "0.012",
      minOrder: 100,
      maxOrder: 50000,
      isActive: true,
    },
    {
      categoryId: instagramId,
      name: "Instagram Likes - Instant",
      description: "Instant Instagram likes from active users. Perfect for boosting post engagement.",
      pricePerUnit: "0.008",
      minOrder: 50,
      maxOrder: 10000,
      isActive: true,
    },
    {
      categoryId: instagramId,
      name: "Instagram Views - Story/Reel",
      description: "High-quality views for your Instagram stories and reels. 100% real and safe.",
      pricePerUnit: "0.005",
      minOrder: 100,
      maxOrder: 100000,
      isActive: true,
    },
    {
      categoryId: youtubeId,
      name: "YouTube Views - Real & Permanent",
      description: "Authentic YouTube views from genuine users. Retention guaranteed, AdSense safe.",
      pricePerUnit: "0.015",
      minOrder: 100,
      maxOrder: 100000,
      isActive: true,
    },
    {
      categoryId: youtubeId,
      name: "YouTube Subscribers - Organic",
      description: "Real YouTube subscribers that stay. Perfect for monetization requirements.",
      pricePerUnit: "0.35",
      minOrder: 10,
      maxOrder: 5000,
      isActive: true,
    },
    {
      categoryId: youtubeId,
      name: "YouTube Likes - Instant Delivery",
      description: "Quick YouTube likes to boost video ranking and social proof.",
      pricePerUnit: "0.02",
      minOrder: 50,
      maxOrder: 10000,
      isActive: true,
    },
    {
      categoryId: facebookId,
      name: "Facebook Page Likes - Real Users",
      description: "Genuine Facebook page likes from active accounts worldwide.",
      pricePerUnit: "0.015",
      minOrder: 100,
      maxOrder: 10000,
      isActive: true,
    },
    {
      categoryId: facebookId,
      name: "Facebook Post Likes - Instant",
      description: "Quick Facebook post likes to increase engagement and reach.",
      pricePerUnit: "0.01",
      minOrder: 50,
      maxOrder: 5000,
      isActive: true,
    },
    {
      categoryId: telegramId,
      name: "Telegram Channel Members - Real & Active",
      description: "Grow your Telegram channel with genuine subscribers who engage.",
      pricePerUnit: "0.025",
      minOrder: 100,
      maxOrder: 50000,
      isActive: true,
    },
    {
      categoryId: telegramId,
      name: "Telegram Group Members - High Quality",
      description: "Add real members to your Telegram groups. Permanent and active.",
      pricePerUnit: "0.022",
      minOrder: 100,
      maxOrder: 30000,
      isActive: true,
    },
    {
      categoryId: telegramId,
      name: "Telegram Post Views - Instant",
      description: "Boost your Telegram post visibility with real views.",
      pricePerUnit: "0.003",
      minOrder: 500,
      maxOrder: 100000,
      isActive: true,
    },
    {
      categoryId: othersId,
      name: "Twitter Followers - Active Accounts",
      description: "Real Twitter followers from active users. Grow your influence organically.",
      pricePerUnit: "0.018",
      minOrder: 100,
      maxOrder: 20000,
      isActive: true,
    },
    {
      categoryId: othersId,
      name: "Twitter Retweets - Fast Delivery",
      description: "Instant Twitter retweets to amplify your message and reach.",
      pricePerUnit: "0.02",
      minOrder: 10,
      maxOrder: 5000,
      isActive: true,
    },
    {
      categoryId: othersId,
      name: "LinkedIn Followers - Professional Network",
      description: "Build your LinkedIn network with real professionals.",
      pricePerUnit: "0.05",
      minOrder: 50,
      maxOrder: 5000,
      isActive: true,
    },
    {
      categoryId: othersId,
      name: "Spotify Plays - Monthly Listeners",
      description: "Boost your Spotify track with real plays from active listeners.",
      pricePerUnit: "0.008",
      minOrder: 1000,
      maxOrder: 100000,
      isActive: true,
    },
  ];

  console.log("Creating services...");
  const createdServices = await db
    .insert(services)
    .values(servicesData)
    .onConflictDoNothing()
    .returning();

  console.log(`Created ${createdServices.length} services`);
  console.log("Database seeded successfully!");
  process.exit(0);
}

seed().catch((error) => {
  console.error("Error seeding database:", error);
  process.exit(1);
});
