# ProGrowSMM Design Guidelines

## Design Approach
**Reference-Based**: Premium SMM panel aesthetic inspired by SMM Birla, featuring dark gradients, neon blue accents, and glass-morphism effects for a high-end, modern feel.

## Visual Treatment (User-Specified)
- **Dark gradient backgrounds** throughout the application
- **Neon blue glow effects** on interactive elements and accents
- **Glass-morphism cards** with blur effects (backdrop-filter: blur)
- **Premium, futuristic aesthetic** with glowing borders and subtle animations

## Typography Hierarchy
- **Headings**: Bold, modern sans-serif (Inter or Poppins via Google Fonts)
  - H1: 3xl-4xl (hero sections), extra-bold weight
  - H2: 2xl-3xl (section headers), bold weight
  - H3: xl-2xl (card titles), semibold weight
- **Body**: Regular weight, base to lg sizes
- **Accent Text**: Use gradient text effects for key CTAs and numbers

## Layout System & Spacing
- **Spacing Units**: Tailwind units of 4, 6, 8, 12, 16, 20, 24 (p-4, gap-8, py-20, etc.)
- **Container**: max-w-7xl for main content areas
- **Section Padding**: py-16 to py-24 for desktop, py-8 to py-12 for mobile
- **Card Spacing**: p-6 to p-8 internal padding, gap-6 between cards

## Landing Page Structure

### Hero Section
- **Layout**: Full-width, min-height 90vh, centered content
- **Elements**: 
  - ProGrowSMM logo (top-left or center)
  - Large headline: "Fastest SMM Panel" with gradient text effect
  - Subheading with value proposition
  - Dual CTAs: Primary "Get Started" + Secondary "View Services" with neon-blue gradient backgrounds and glow effects
  - Floating glass cards with live stats (users, orders, services)
- **Background**: Dark gradient with animated particles or subtle geometric patterns

### Why Choose Us Section
- **Layout**: 3-4 column grid (lg:grid-cols-3 xl:grid-cols-4), single column on mobile
- **Cards**: Glass-effect cards with:
  - Icon placeholder at top (neon blue accent)
  - Bold title (text-xl)
  - Description text (2-3 lines)
  - Subtle hover glow effect
  - Border with gradient outline

### Orders Completed Counter
- **Layout**: Full-width section with dark gradient background
- **Elements**:
  - Animated number counter (large text, 5xl-6xl)
  - "Orders Completed" label
  - Additional stats in grid: Active Users, Services Available, Success Rate
  - Each stat in glass card with neon glow

### Testimonials (Include)
- **Layout**: 2-3 column grid, carousel on mobile
- **Cards**: Glass-effect testimonial cards with:
  - Avatar placeholder (circular)
  - Quote text
  - Name and role
  - Star rating with neon blue stars

### Footer
- **Layout**: Multi-column (4 columns on desktop, stacked on mobile)
- **Sections**: Quick Links, Services, Support, Social Media
- **Glass treatment** with subtle blur effect
- Copyright and logo at bottom

## Authentication Pages (Login/Register)

### Layout
- **Centered card design** on gradient background
- **Glass-morphism container** (max-w-md) with:
  - ProGrowSMM logo at top
  - Form title (Welcome Back / Create Account)
  - Input fields with glass styling and neon blue focus states
  - Primary CTA button with neon-blue gradient + glow
  - Divider with "OR" text
  - Google OAuth button with glass effect
  - Link to opposite page (Don't have an account? / Already have an account?)

### Form Elements
- **Input fields**: Glass background, border with subtle glow, neon blue focus ring
- **Buttons**: Full-width, rounded-lg, gradient background, glow effect on hover
- **Social button**: Glass effect with Google icon, border glow

## Dashboard Page

### Layout Structure
- **Sidebar Navigation** (left, glass effect):
  - ProGrowSMM logo
  - Navigation items with icons (Dashboard, New Order, Orders, Services, Wallet, Settings)
  - User profile section at bottom
- **Main Content Area**:
  - Welcome header with user name
  - Stats grid (2x2 or 4 columns): Orders Completed, Balance, Active Services, Pending Orders
  - Recent activity/orders section
  - Quick actions cards

### Stats Cards
- Glass-morphism design with:
  - Icon with neon blue background
  - Large number (animated counter)
  - Label text
  - Trend indicator (optional)
  - Glow border effect

## Component Library

### Buttons
- **Primary**: Neon-blue gradient background, white text, glow effect, rounded-lg, px-8 py-3
- **Secondary**: Glass background, border with gradient, white text, rounded-lg
- **When on images**: Add backdrop-blur-md to button backgrounds

### Cards
- **Glass Effect**: backdrop-filter: blur, semi-transparent background, border with gradient, rounded-xl, p-6
- **Hover State**: Increase glow intensity, subtle scale transform

### Navigation
- **Header**: Sticky, glass background, logo left, nav links center, auth buttons right
- **Mobile**: Hamburger menu with slide-in glass panel

### Forms
- **Input Fields**: Glass background, rounded-lg, border with subtle glow, px-4 py-3, neon blue focus ring
- **Labels**: Text-sm, semibold, mb-2
- **Error States**: Red glow border, error message below field

## Responsive Breakpoints
- **Mobile**: base (320px+) - single column layouts, stacked cards
- **Tablet**: md (768px+) - 2 column grids, visible sidebar
- **Desktop**: lg (1024px+) - 3-4 column grids, full sidebar
- **Large Desktop**: xl (1280px+) - max content width, enhanced spacing

## Images
- **Hero Background**: Abstract tech/network visualization with dark gradient overlay (full-width, behind content)
- **Why Choose Us Cards**: Icon placeholders - use Font Awesome or Heroicons for speed, quality, reliability icons
- **Dashboard**: User avatar placeholder (circular, glass border)

## Animation Guidelines
- **Counters**: Use CountUp.js or similar for number animations on scroll into view
- **Cards**: Subtle hover scale (1.02-1.05) and glow intensity increase
- **Page Transitions**: Fade in content on load
- **Buttons**: Glow pulse effect on hover
- **Minimize**: Avoid excessive animations; focus on purposeful micro-interactions

## Key Design Principles
1. **Premium Feel**: Every element should feel polished with glass effects and glows
2. **Dark Aesthetic**: Maintain dark theme consistency across all pages
3. **Neon Accents**: Use blue neon strategically for CTAs, borders, and focus states
4. **Clear Hierarchy**: Bold typography and spacing create obvious content flow
5. **Responsive First**: Ensure glass effects and gradients work on all screen sizes