import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  Wallet, 
  Settings, 
  LogOut,
  TrendingUp,
  Clock,
  CheckCircle2,
  DollarSign,
  Zap,
  Plus,
  Loader2
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { getToken, logout, getStoredUser } from "@/lib/auth";

export default function Dashboard() {
  const [location, setLocation] = useLocation();
  
  useEffect(() => {
    const token = getToken();
    if (!token) {
      setLocation("/login");
    }
  }, [setLocation]);

  const { data: userData, isLoading } = useQuery({
    queryKey: ["/api/user"],
    enabled: !!getToken(),
  });

  const storedUser = getStoredUser();
  const user = userData || storedUser || {
    username: "User",
    email: "user@example.com",
    avatar: null,
    balance: 0,
    ordersCompleted: 0,
    activeServices: 0,
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
    { icon: ShoppingCart, label: "New Order", path: "/dashboard/new-order" },
    { icon: Package, label: "Orders", path: "/dashboard/orders" },
    { icon: Wallet, label: "Wallet", path: "/dashboard/wallet" },
    { icon: Settings, label: "Settings", path: "/dashboard/settings" },
  ];

  const recentActivity = [
    { service: "Instagram Followers", quantity: 1000, status: "completed", time: "2 hours ago" },
    { service: "YouTube Views", quantity: 5000, status: "processing", time: "5 hours ago" },
    { service: "TikTok Likes", quantity: 2500, status: "completed", time: "1 day ago" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex">
      <aside className="w-64 glass-card border-r border-border/50 flex flex-col">
        <div className="p-6 border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-md bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center neon-glow-sm">
              <Zap className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold gradient-text" data-testid="text-logo">ProGrowSMM</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                className={`w-full justify-start gap-3 ${
                  location === item.path 
                    ? "bg-primary/10 text-primary hover:bg-primary/20" 
                    : "hover-elevate"
                }`}
                data-testid={`button-nav-${item.label.toLowerCase().replace(" ", "-")}`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Button>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-border/50">
          <div className="flex items-center gap-3 mb-4">
            <Avatar className="border-2 border-primary/50 neon-glow-sm">
              <AvatarFallback className="bg-gradient-to-br from-primary to-blue-600 text-primary-foreground font-semibold">
                {getInitials(user.username || "User")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-foreground truncate" data-testid="text-username">
                {user.username}
              </div>
              <div className="text-xs text-muted-foreground truncate" data-testid="text-email">
                {user.email}
              </div>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="w-full glass-card border-border/50" 
            onClick={logout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Log Out
          </Button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <div className="p-6 sm:p-8 max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2" data-testid="text-welcome">
              Welcome back, <span className="gradient-text">{user.username}</span>!
            </h1>
            <p className="text-muted-foreground" data-testid="text-dashboard-subtitle">
              Here's what's happening with your account today
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[
              {
                icon: CheckCircle2,
                label: "Orders Completed",
                value: user.ordersCompleted || 0,
                color: "from-green-500 to-emerald-500",
                testId: "completed"
              },
              {
                icon: DollarSign,
                label: "Balance",
                value: `$${(user.balance || 0).toFixed(2)}`,
                color: "from-blue-500 to-cyan-500",
                testId: "balance"
              },
              {
                icon: TrendingUp,
                label: "Active Services",
                value: user.activeServices || 0,
                color: "from-purple-500 to-pink-500",
                testId: "active"
              },
              {
                icon: Clock,
                label: "Pending Orders",
                value: 0,
                color: "from-yellow-500 to-orange-500",
                testId: "pending"
              }
            ].map((stat) => (
              <Card key={stat.label} className="glass-card p-6 border-border/50 hover-elevate" data-testid={`card-stat-${stat.testId}`}>
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center neon-glow-sm`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-foreground mb-1" data-testid={`text-stat-value-${stat.testId}`}>
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground" data-testid={`text-stat-label-${stat.testId}`}>
                  {stat.label}
                </div>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="glass-card p-6 border-border/50 lg:col-span-2" data-testid="card-recent-activity">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-foreground" data-testid="text-recent-activity">
                  Recent Activity
                </h2>
                <Link href="/dashboard/orders">
                  <Button variant="ghost" size="sm" data-testid="button-view-all">
                    View All
                  </Button>
                </Link>
              </div>

              <div className="space-y-4">
                {recentActivity.map((activity, idx) => (
                  <div 
                    key={idx} 
                    className="flex items-center justify-between p-4 rounded-lg glass border border-border/50 hover-elevate"
                    data-testid={`item-activity-${idx}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                        <Package className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground" data-testid={`text-activity-service-${idx}`}>
                          {activity.service}
                        </div>
                        <div className="text-sm text-muted-foreground" data-testid={`text-activity-time-${idx}`}>
                          {activity.quantity.toLocaleString()} • {activity.time}
                        </div>
                      </div>
                    </div>
                    <Badge
                      variant={activity.status === "completed" ? "default" : "secondary"}
                      className={activity.status === "completed" ? "neon-glow-sm" : ""}
                      data-testid={`badge-activity-status-${idx}`}
                    >
                      {activity.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="glass-card p-6 border-border/50" data-testid="card-quick-actions">
              <h2 className="text-xl font-semibold text-foreground mb-6" data-testid="text-quick-actions">
                Quick Actions
              </h2>

              <div className="space-y-3">
                <Button className="w-full neon-glow justify-start" data-testid="button-new-order">
                  <Plus className="w-4 h-4 mr-2" />
                  New Order
                </Button>
                <Button variant="outline" className="w-full glass-card border-border/50 justify-start" data-testid="button-add-funds">
                  <Wallet className="w-4 h-4 mr-2" />
                  Add Funds
                </Button>
                <Button variant="outline" className="w-full glass-card border-border/50 justify-start" data-testid="button-view-services">
                  <Package className="w-4 h-4 mr-2" />
                  View Services
                </Button>
              </div>

              <div className="mt-8 p-4 rounded-lg bg-gradient-to-br from-primary/10 to-blue-600/10 border border-primary/20">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-md bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <Zap className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1" data-testid="text-promo-title">
                      Premium Member
                    </h3>
                    <p className="text-sm text-muted-foreground" data-testid="text-promo-desc">
                      Enjoy 20% off on all orders this month!
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
