import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerSchema, loginSchema } from "@shared/schema";
import { hashPassword, comparePassword, generateToken } from "./auth";
import { authenticateToken, type AuthRequest } from "./middleware/auth";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || "";
const BASE_URL = process.env.REPL_ID 
  ? `https://${process.env.REPL_ID}.replit.app` 
  : "http://localhost:5000";

passport.use(
  new GoogleStrategy(
    {
      clientID: GOOGLE_CLIENT_ID,
      clientSecret: GOOGLE_CLIENT_SECRET,
      callbackURL: `${BASE_URL}/api/auth/google/callback`,
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        const email = profile.emails?.[0]?.value;
        if (!email) {
          return done(new Error("No email found in Google profile"));
        }

        let user = await storage.getUserByGoogleId(profile.id);

        if (!user) {
          user = await storage.getUserByEmail(email);
          
          if (!user) {
            user = await storage.createUser({
              email,
              username: profile.displayName || email.split("@")[0],
              googleId: profile.id,
              avatar: profile.photos?.[0]?.value,
            });
          }
        }

        return done(null, user);
      } catch (error) {
        return done(error as Error);
      }
    }
  )
);

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(passport.initialize());

  app.post("/api/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);

      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const hashedPassword = await hashPassword(validatedData.password);

      const user = await storage.createUser({
        email: validatedData.email,
        username: validatedData.username,
        password: hashedPassword,
      });

      const token = generateToken(user);

      res.json({
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          avatar: user.avatar,
          balance: user.balance,
          ordersCompleted: user.ordersCompleted,
          activeServices: user.activeServices,
        },
      });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);

      const user = await storage.getUserByEmail(validatedData.email);
      if (!user || !user.password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const isValidPassword = await comparePassword(
        validatedData.password,
        user.password
      );

      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const token = generateToken(user);

      res.json({
        token,
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          avatar: user.avatar,
          balance: user.balance,
          ordersCompleted: user.ordersCompleted,
          activeServices: user.activeServices,
        },
      });
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  app.get(
    "/api/auth/google",
    passport.authenticate("google", { scope: ["profile", "email"] })
  );

  app.get(
    "/api/auth/google/callback",
    passport.authenticate("google", { 
      session: false,
      failureRedirect: "/login?error=google_auth_failed" 
    }),
    (req, res) => {
      const user = req.user as any;
      const token = generateToken(user);
      
      const userInfo = {
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        balance: user.balance,
        ordersCompleted: user.ordersCompleted,
        activeServices: user.activeServices,
      };
      
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Authentication Success</title>
          <style>
            body {
              margin: 0;
              padding: 0;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
              color: white;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100vh;
            }
            .container {
              text-align: center;
            }
            .spinner {
              border: 4px solid rgba(0, 191, 255, 0.2);
              border-top: 4px solid #00bfff;
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite;
              margin: 0 auto 20px;
            }
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="spinner"></div>
            <h2>Authentication Successful</h2>
            <p>Redirecting to dashboard...</p>
          </div>
          <script>
            try {
              localStorage.setItem('progrowsmm_token', ${JSON.stringify(token)});
              localStorage.setItem('progrowsmm_user', ${JSON.stringify(JSON.stringify(userInfo))});
              window.location.href = '/dashboard';
            } catch (error) {
              console.error('Error storing credentials:', error);
              window.location.href = '/login?error=storage_failed';
            }
          </script>
        </body>
        </html>
      `);
    }
  );

  app.get("/api/user", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: user.id,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        balance: user.balance,
        ordersCompleted: user.ordersCompleted,
        activeServices: user.activeServices,
      });
    } catch (error: any) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
